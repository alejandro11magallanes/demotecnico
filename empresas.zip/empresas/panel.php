<?php

session_start();
if (!isset($_SESSION['rol'])) {
    header("location: login.php");
} else {
    if ($_SESSION['rol'] != 1) {
        header("location: login.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="shortcut icon" href="../img/icono.png" />
    <link rel="stylesheet" href="../css/style.css" />
    <title>Administracion de empresas</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg" id="nav">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.html">
                <img src="../img/logo1.png" alt="Logo" width="200" class="d-inline-block align-text-top" />
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li style="margin-left: 30px" class="nav-item ">
                        <a class="nav-link active" href="../inicioadmin.php">Perfil del Usuario</a>
                    </li>
                    <li style="margin-left: 30px" class="nav-item">
                        <a class="nav-link" href="">Empresa</a>
                    </li>
                    <li style="margin-left: 30px" class="nav-item">
                        <a class="nav-link" href="empresasxusuario/panel.php">Reportes de empresa</a>
                    </li>
                    <li style="margin-left: 30px" class="nav-item">
                        <a class="nav-link" href="reportes/panel.php">Contactos</a>
                    </li>
                    <li style="margin-left: 30px" class="nav-item">
                        <a class="nav-link" href="reportes/fecha.php">Reportes de contactos</a>
                    </li>
                </ul>
            </div>
            <div class="navbar-brand">
                <button id="cerrar-boton" class="btn" onclick="location.href='login.php?cerrar_sesion=1'">
                    Cerrar Sesion
                </button>
            </div>
        </div>
    </nav>
    <div class="container mt-3">
        <div class="row justify-content-md-center">
            <div class="col-md-12">
                <h2 class="text-center mt-3">Mantenimiento de Empresas</h2>
                <hr class="mb-3">
            </div>
            <div class="col-md-4 mb-3">
                <h3 class="text-center">Asigna una empresa a un usuario</h3>

                <form method="POST" action="action.php" enctype="multipart/form-data" autocomplete="off">
                    <div class="mb-3">
                        <label for="Sexo">Usuario</label>
                        <select class="form-select" name="usuario" required>
                            <option value="" selected>Seleccione un usuario</option>
                            <?php
                            include 'connect.php';

                            $consultaUsuario = "SELECT * FROM usuarios";
                            $ejectuar = mysqli_query($con, $consultaUsuario);


                            foreach ($ejectuar as $opciones) :

                            ?>

                            <option value="<?php echo $opciones['id']; ?>"><?php echo $opciones['username']; ?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <!-- <input type="text" name="metodo" value="1" hidden> -->
                    <div class="mb-3">

                        <input type="text" class="form-control" name="rfc" value="Por Asignar" hidden>
                    </div>
                    <div class="mb-3">

                        <input type="text" name="razon" class="form-control" value="Por Asignar" hidden>
                    </div>
                    <div class="mb-3">

                        <input type="text" name="cp" class="form-control" value="Por Asignar" hidden>
                    </div>
                    <div class="mb-3">

                        <input type="text" name="pass" class="form-control" value="Por Asignar" hidden>
                    </div>
                    <div class="mb-3">

                        <input type="text" name="cfdi" class="form-control" value="25" hidden>
                    </div>
                    <div class="mb-3">

                        <input type="text" name="regimen" class="form-control" value="22" hidden>
                        <div class="mb-3">
                            <label for="Sexo">Plan</label>
                            <select class="form-select" name="plan" id="section" required>
                                <option value="">Asigne un plan </option>
                                <option value="A">Plan Basico</option>
                                <option value="B">Plan Medio</option>
                                <option value="C">Plan Premium</option>
                            </select>
                        </div>

                        <div class="d-grid gap-2 col-12 mx-auto">
                            <button type="submit" class="btn  btn btn-primary mt-3 mb-2">
                                Registrar Empresa por Usuario
                                <i class="bi bi-arrow-right-circle"></i>
                            </button>
                        </div>

                </form>
            </div>
        </div>
    </div>
</body>

</html>