<?php
include('connect.php');

$idusuario = filter_var($_POST['usuario'], FILTER_SANITIZE_STRING);
$rfc =  filter_var($_POST['rfc'], FILTER_SANITIZE_STRING);
$razon = filter_var($_POST['razon'], FILTER_SANITIZE_STRING);
$cp = filter_var($_POST['cp'], FILTER_SANITIZE_STRING);
$contasat = filter_var($_POST['pass'], FILTER_SANITIZE_STRING);
$cfdi = filter_var($_POST['cfdi'], FILTER_SANITIZE_STRING);
$regimen = filter_var($_POST['regimen'], FILTER_SANITIZE_STRING);
$plan = filter_var($_POST['plan'], FILTER_SANITIZE_STRING);


$insertUsuario = ("INSERT INTO empresas(rfc,razon,cp,contraseñasat,cfdi,regimen,plan,usuario)VALUES(
    '" . $rfc . "',
    '" . $razon . "',
    '" . $cp . "',
    '" . $contasat . "',
    '" . $cfdi . "',
    '" . $regimen . "',
    '" . $plan . "',
    '" . $idusuario . "'
)");
$resulInsert = mysqli_query($con, $insertUsuario);
echo "<script> alert('La empresa a sido ligada con el usuario'); </script>";
header("Location:panel.php");